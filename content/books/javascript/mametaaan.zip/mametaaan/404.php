<?php get_header(); ?>

<div class="error-page">
    <h1 class="error-page__title">404</h1>
    <p class="error-page__message">お探しのページは見つかりませんでした。</p>
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="error-page__link">トップページへ戻る</a>
</div>

<?php get_footer(); ?>
