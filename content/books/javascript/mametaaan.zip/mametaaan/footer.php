</main>

<footer class="site-footer">
    <div class="site-footer__inner">
        <nav class="site-footer__nav" aria-label="フッターナビゲーション">
            <?php
            wp_nav_menu( [
                'theme_location' => 'footer',
                'container'      => false,
                'menu_class'     => 'site-footer__list',
                'fallback_cb'    => false,
                'depth'          => 1,
            ] );
            ?>
        </nav>
        <p class="site-footer__copy">
            &copy; <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>
        </p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
