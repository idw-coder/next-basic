<?php
/**
 * テーマ設定ファイル
 * 表示件数などの設定値を一元管理
 */

return [
    // フロントページ: 最新記事の表示件数
    'latest_posts_count'   => 6,

    // フロントページ: 最新レシピの表示件数
    'latest_recipes_count' => 6,

    // フロントページ: 人気記事ランキングの表示件数
    'popular_posts_count'  => 5,

    // レシピカテゴリーのスラッグ
    'recipe_category_slug' => 'recipe',

    // Google AdSense
    'adsense_client_id'    => '', // ca-pub-XXXXXXXXXXXXXXXX
    'adsense_slot_before'  => '', // 記事上の広告スロットID
    'adsense_slot_after'   => '', // 記事下の広告スロットID

    // GA4
    'ga4_measurement_id'   => '', // G-XXXXXXXXXX
];
