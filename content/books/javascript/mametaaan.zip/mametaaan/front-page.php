<?php get_header(); ?>

<div class="front-page">

    <!-- ヒーロー: 固定ページのコンテンツ（本人がブロックエディタで編集） -->
    <section class="hero">
        <div class="hero__inner">
            <?php
            while ( have_posts() ) : the_post();
                the_content();
            endwhile;
            ?>
        </div>
    </section>

    <!-- 最新記事 -->
    <?php
    $latest_query = new WP_Query( [
        'posts_per_page'      => mametaaan_get_config( 'latest_posts_count' ),
        'ignore_sticky_posts' => true,
    ] );
    if ( $latest_query->have_posts() ) :
    ?>
    <section class="front-section">
        <h2 class="front-section__title">最新の記事</h2>
        <div class="post-grid">
            <?php while ( $latest_query->have_posts() ) : $latest_query->the_post(); ?>
                <article class="post-card">
                    <a href="<?php the_permalink(); ?>" class="post-card__link">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-card__thumb">
                                <?php the_post_thumbnail( 'mametaaan-card' ); ?>
                            </div>
                        <?php endif; ?>
                        <div class="post-card__body">
                            <h3 class="post-card__title"><?php the_title(); ?></h3>
                            <time class="post-card__date" datetime="<?php echo get_the_date( 'Y-m-d' ); ?>">
                                <?php echo get_the_date(); ?>
                            </time>
                        </div>
                    </a>
                </article>
            <?php endwhile; ?>
        </div>
    </section>
    <?php wp_reset_postdata(); endif; ?>

    <!-- 最新レシピ -->
    <?php
    $recipe_slug = mametaaan_get_config( 'recipe_category_slug' );
    $recipe_query = new WP_Query( [
        'posts_per_page'      => mametaaan_get_config( 'latest_recipes_count' ),
        'category_name'       => $recipe_slug,
        'ignore_sticky_posts' => true,
    ] );
    if ( $recipe_query->have_posts() ) :
    ?>
    <section class="front-section">
        <h2 class="front-section__title">最新のレシピ</h2>
        <div class="post-grid">
            <?php while ( $recipe_query->have_posts() ) : $recipe_query->the_post(); ?>
                <article class="post-card">
                    <a href="<?php the_permalink(); ?>" class="post-card__link">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-card__thumb">
                                <?php the_post_thumbnail( 'mametaaan-card' ); ?>
                            </div>
                        <?php endif; ?>
                        <div class="post-card__body">
                            <h3 class="post-card__title"><?php the_title(); ?></h3>
                            <time class="post-card__date" datetime="<?php echo get_the_date( 'Y-m-d' ); ?>">
                                <?php echo get_the_date(); ?>
                            </time>
                        </div>
                    </a>
                </article>
            <?php endwhile; ?>
        </div>
    </section>
    <?php wp_reset_postdata(); endif; ?>

    <!-- 人気記事ランキング -->
    <?php
    $popular_query = mametaaan_get_popular_posts();
    if ( $popular_query->have_posts() ) :
    ?>
    <section class="front-section">
        <h2 class="front-section__title">人気の記事</h2>
        <ol class="ranking-list">
            <?php $rank = 1; while ( $popular_query->have_posts() ) : $popular_query->the_post(); ?>
                <li class="ranking-item">
                    <a href="<?php the_permalink(); ?>" class="ranking-item__link">
                        <span class="ranking-item__rank"><?php echo $rank; ?></span>
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="ranking-item__thumb">
                                <?php the_post_thumbnail( 'thumbnail' ); ?>
                            </div>
                        <?php endif; ?>
                        <div class="ranking-item__body">
                            <h3 class="ranking-item__title"><?php the_title(); ?></h3>
                            <time class="ranking-item__date" datetime="<?php echo get_the_date( 'Y-m-d' ); ?>">
                                <?php echo get_the_date(); ?>
                            </time>
                        </div>
                    </a>
                </li>
            <?php $rank++; endwhile; ?>
        </ol>
    </section>
    <?php wp_reset_postdata(); endif; ?>

</div>

<?php get_footer(); ?>
