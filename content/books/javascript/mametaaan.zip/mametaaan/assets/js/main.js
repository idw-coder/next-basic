document.addEventListener('DOMContentLoaded', function () {
  var hamburger = document.querySelector('.hamburger');
  var nav = document.querySelector('.site-nav');
  var body = document.body;

  if (!hamburger || !nav) return;

  hamburger.addEventListener('click', function () {
    var isOpen = hamburger.getAttribute('aria-expanded') === 'true';
    hamburger.setAttribute('aria-expanded', !isOpen);
    hamburger.classList.toggle('is-active');
    nav.classList.toggle('is-open');
    body.classList.toggle('nav-open');
  });

  // リサイズでPC幅になったらメニューを閉じる
  window.addEventListener('resize', function () {
    if (window.innerWidth >= 768) {
      hamburger.setAttribute('aria-expanded', 'false');
      hamburger.classList.remove('is-active');
      nav.classList.remove('is-open');
      body.classList.remove('nav-open');
    }
  });

  // メニュー内のリンクをクリックしたら閉じる
  var links = nav.querySelectorAll('a');
  for (var i = 0; i < links.length; i++) {
    links[i].addEventListener('click', function () {
      hamburger.setAttribute('aria-expanded', 'false');
      hamburger.classList.remove('is-active');
      nav.classList.remove('is-open');
      body.classList.remove('nav-open');
    });
  }
});
