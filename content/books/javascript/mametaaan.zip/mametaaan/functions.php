<?php
/**
 * mametaaan テーマ functions.php
 */

// 設定ファイル読み込み
function mametaaan_get_config( $key = null ) {
    static $config = null;
    if ( $config === null ) {
        $config = require get_template_directory() . '/config.php';
    }
    if ( $key !== null ) {
        return isset( $config[ $key ] ) ? $config[ $key ] : null;
    }
    return $config;
}

/**
 * テーマセットアップ
 */
function mametaaan_setup() {
    // タイトルタグの自動出力
    add_theme_support( 'title-tag' );

    // アイキャッチ画像の有効化
    add_theme_support( 'post-thumbnails' );

    // カスタムサムネイルサイズ
    add_image_size( 'mametaaan-card', 600, 400, true );
    add_image_size( 'mametaaan-hero', 1200, 600, true );

    // ナビゲーションメニュー
    register_nav_menus( [
        'primary' => 'メインメニュー',
        'footer'  => 'フッターメニュー',
    ] );

    // HTML5マークアップ
    add_theme_support( 'html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ] );

    // Gutenbergのワイド幅・全幅ブロック対応
    add_theme_support( 'align-wide' );

    // エディタースタイル
    add_theme_support( 'editor-styles' );
}
add_action( 'after_setup_theme', 'mametaaan_setup' );

/**
 * スタイル・スクリプトの読み込み
 */
function mametaaan_enqueue_assets() {
    // メインCSS
    wp_enqueue_style(
        'mametaaan-style',
        get_template_directory_uri() . '/assets/css/style.css',
        [],
        filemtime( get_template_directory() . '/assets/css/style.css' )
    );

    // メインJS
    wp_enqueue_script(
        'mametaaan-script',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        filemtime( get_template_directory() . '/assets/js/main.js' ),
        true
    );
}
add_action( 'wp_enqueue_scripts', 'mametaaan_enqueue_assets' );

/**
 * GA4 トラッキングコード
 */
function mametaaan_ga4_head() {
    $ga4_id = mametaaan_get_config( 'ga4_measurement_id' );
    if ( empty( $ga4_id ) ) {
        return;
    }
    ?>
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo esc_attr( $ga4_id ); ?>"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '<?php echo esc_js( $ga4_id ); ?>');
    </script>
    <?php
}
add_action( 'wp_head', 'mametaaan_ga4_head', 1 );

/**
 * Google AdSense 表示ヘルパー
 */
function mametaaan_adsense( $slot_key ) {
    $client_id = mametaaan_get_config( 'adsense_client_id' );
    $slot_id   = mametaaan_get_config( $slot_key );
    if ( empty( $client_id ) || empty( $slot_id ) ) {
        return;
    }
    ?>
    <div class="ad-unit">
        <ins class="adsbygoogle"
             style="display:block"
             data-ad-client="<?php echo esc_attr( $client_id ); ?>"
             data-ad-slot="<?php echo esc_attr( $slot_id ); ?>"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
        <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
    </div>
    <?php
}

/**
 * 人気記事取得（WP Statistics連携）
 */
function mametaaan_get_popular_posts( $count = null ) {
    if ( $count === null ) {
        $count = mametaaan_get_config( 'popular_posts_count' );
    }

    // WP Statisticsが有効な場合
    if ( function_exists( 'wp_statistics_get_top_pages' ) ) {
        $top_pages = wp_statistics_get_top_pages( $count );
        if ( ! empty( $top_pages ) ) {
            $post_ids = [];
            foreach ( $top_pages as $page ) {
                if ( isset( $page['id'] ) && get_post_type( $page['id'] ) === 'post' ) {
                    $post_ids[] = $page['id'];
                }
            }
            if ( ! empty( $post_ids ) ) {
                return new WP_Query( [
                    'post__in'            => $post_ids,
                    'orderby'             => 'post__in',
                    'posts_per_page'      => $count,
                    'ignore_sticky_posts' => true,
                ] );
            }
        }
    }

    // フォールバック: コメント数順
    return new WP_Query( [
        'posts_per_page'      => $count,
        'orderby'             => 'comment_count',
        'order'               => 'DESC',
        'ignore_sticky_posts' => true,
    ] );
}

/**
 * 抜粋の文字数
 */
function mametaaan_excerpt_length( $length ) {
    return 80;
}
add_filter( 'excerpt_length', 'mametaaan_excerpt_length' );

/**
 * 抜粋の末尾
 */
function mametaaan_excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'mametaaan_excerpt_more' );

/**
 * サムネイルURL取得（フォールバック付き）
 */
function mametaaan_get_thumb_url( $size = 'mametaaan-card' ) {
    if ( has_post_thumbnail() ) {
        return get_the_post_thumbnail_url( get_the_ID(), $size );
    }
    return get_template_directory_uri() . '/assets/images/sample01.jpg';
}