<?php get_header(); ?>

<div class="content-area">
    <?php if ( have_posts() ) : ?>
        <div class="post-list">
            <?php while ( have_posts() ) : the_post(); ?>
                <article class="post-card">
                    <a href="<?php the_permalink(); ?>" class="post-card__link">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-card__thumb">
                                <?php the_post_thumbnail( 'mametaaan-card' ); ?>
                            </div>
                        <?php endif; ?>
                        <div class="post-card__body">
                            <h2 class="post-card__title"><?php the_title(); ?></h2>
                            <time class="post-card__date" datetime="<?php echo get_the_date( 'Y-m-d' ); ?>">
                                <?php echo get_the_date(); ?>
                            </time>
                            <p class="post-card__excerpt"><?php echo get_the_excerpt(); ?></p>
                        </div>
                    </a>
                </article>
            <?php endwhile; ?>
        </div>

        <nav class="pagination">
            <?php the_posts_pagination( [
                'prev_text' => '&laquo; 前へ',
                'next_text' => '次へ &raquo;',
            ] ); ?>
        </nav>
    <?php else : ?>
        <p class="no-posts">記事が見つかりませんでした。</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
