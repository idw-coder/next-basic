<?php get_header(); ?>

<article class="single-post">
    <?php while ( have_posts() ) : the_post(); ?>

        <?php $thumb_url = mametaaan_get_thumb_url( 'mametaaan-hero' ); ?>
        <header class="single-post__header" style="--hero-bg: url('<?php echo esc_url( $thumb_url ); ?>');">
            <div class="single-post__header-bg" aria-hidden="true"></div>
            <div class="single-post__header-overlay" aria-hidden="true"></div>
            <div class="single-post__header-inner">
                <div class="single-post__meta">
                    <?php
                    $categories = get_the_category();
                    if ( $categories ) :
                        foreach ( $categories as $cat ) :
                    ?>
                        <a href="<?php echo esc_url( get_category_link( $cat->term_id ) ); ?>" class="single-post__cat">
                            <?php echo esc_html( $cat->name ); ?>
                        </a>
                    <?php
                        endforeach;
                    endif;
                    ?>
                </div>
                <h1 class="single-post__title"><?php the_title(); ?></h1>
                <time class="single-post__date" datetime="<?php echo get_the_date( 'Y-m-d' ); ?>">
                    <?php echo get_the_date(); ?>
                </time>
            </div>
        </header>

        <?php mametaaan_adsense( 'adsense_slot_before' ); ?>

        <div class="single-post__content">
            <?php the_content(); ?>
        </div>

        <?php mametaaan_adsense( 'adsense_slot_after' ); ?>

        <footer class="single-post__footer">
            <?php
            $tags = get_the_tags();
            if ( $tags ) :
            ?>
                <div class="single-post__tags">
                    <?php foreach ( $tags as $tag ) : ?>
                        <a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" class="single-post__tag">
                            #<?php echo esc_html( $tag->name ); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <nav class="post-nav">
                <?php
                $prev = get_previous_post();
                $next = get_next_post();
                ?>
                <?php if ( $prev ) : ?>
                    <a href="<?php echo get_permalink( $prev ); ?>" class="post-nav__link post-nav__link--prev">
                        <span class="post-nav__label">&laquo; 前の記事</span>
                        <span class="post-nav__title"><?php echo esc_html( $prev->post_title ); ?></span>
                    </a>
                <?php endif; ?>
                <?php if ( $next ) : ?>
                    <a href="<?php echo get_permalink( $next ); ?>" class="post-nav__link post-nav__link--next">
                        <span class="post-nav__label">次の記事 &raquo;</span>
                        <span class="post-nav__title"><?php echo esc_html( $next->post_title ); ?></span>
                    </a>
                <?php endif; ?>
            </nav>
        </footer>

    <?php endwhile; ?>
</article>

<?php get_footer(); ?>